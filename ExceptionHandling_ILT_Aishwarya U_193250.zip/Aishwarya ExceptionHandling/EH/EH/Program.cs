﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EH
{
   
            class Program
        {
            public static void Main(string[] args)
            {
                try
                {
               
                    MyCalculator obj =
                          new MyCalculator();
                    int r = obj.Div(800, 0);
                    Console.WriteLine("Result={0}", r);
                }
                catch (MyException ex)
                {
                string filePath = "C:/Users/uarun/source/repos/Sample.txt";
                List<string> lines = File.ReadAllLines(filePath).ToList();
                lines.Add(ex.ErrorDateTime);
                lines.Add(ex.ClientProjectName);
                lines.Add(ex.IpAddr);
                File.WriteAllLines(filePath, lines);
                Console.WriteLine(ex.ErrorDateTime);
                Console.WriteLine(ex.ClientProjectName);
                Console.WriteLine(ex.IpAddr);
              
            }
            FileStream inFile = new FileStream("C:/Users/uarun/source/repos/Sample.txt", FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(inFile);
            string record;
            string input;
            Console.Write("Enter date (m/d/yyyy)  ");
            input = Console.ReadLine();
            try
            {
                
                record = reader.ReadLine();
                while (record != null)
                {
                    if (record.Contains(input))
                    {
                        Console.WriteLine(record);
                        record = reader.ReadLine();
                        Console.WriteLine(record);
                        record = reader.ReadLine();
                        Console.WriteLine(record);
                    }
                    record = reader.ReadLine();
                }
            }
            finally
            {
               
                reader.Close();
                inFile.Close();
            }



        }
    }
}
