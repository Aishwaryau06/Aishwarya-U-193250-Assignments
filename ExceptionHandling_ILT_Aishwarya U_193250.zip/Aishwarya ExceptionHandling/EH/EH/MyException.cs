﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EH
{
    class MyException : ApplicationException
    {
        public string ErrorDateTime { get; set; }
        public string IpAddr { get; set; }
        public string ClientProjectName { get; set; }
    }
    class MyCalculator
    {
        public int Div(int a, int b)
        {
            if (b == 0)
                throw new MyException()
                {
                    ErrorDateTime = DateTime.Now.ToString(),
                    IpAddr = " 192.168.43.120",
                    ClientProjectName = "Exception Handling ",

                };
            else
                return a / b;
        }
    }

}
