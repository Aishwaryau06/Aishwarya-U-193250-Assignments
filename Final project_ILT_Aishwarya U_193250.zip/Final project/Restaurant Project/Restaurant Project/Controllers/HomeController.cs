﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Restaurant_Project.Models;

namespace Restaurant_Project.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult adminlogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult autherize(admin a)
        {
            using (RestaurantDBEntities rdb = new RestaurantDBEntities())
            {
                var v = rdb.admins.Where(x => x.adminname == a.adminname && x.pw == a.pw).FirstOrDefault();
                if(v == null)
                {
                    a.loginerrormsg = "wrong username or password";
                    return View("adminlogin", a);
                }
                else
                {
                    Session["adminname"] = a.adminname;
                    return View("adminedit");
                }
            }
               
        }
        public ActionResult logout()
        {
            Session.Abandon();

            return View("Index");
        }
        public ActionResult adminedit()
        {
            return View();
        }
        public ActionResult signup()
        {
            return View();
        }

        [HttpPost]
        public JsonResult addsignup(string username,
          string passwd,string city)
        {
            RestaurantDBEntities ee = new RestaurantDBEntities();
            usertable e1 = new usertable();
           
            e1.username = username;
            e1.passwd = passwd;
            e1.city = city;
           
            ee.usertables.Add(e1);
            ee.SaveChanges();
            return Json("signed up Successfully");
        }

        public ActionResult userlogin()
        {
            return View();
        }
        [HttpPost]
        public ActionResult autherizeuser(usertable a)
        {
            using (RestaurantDBEntities rdb = new RestaurantDBEntities())
            {
                var v = rdb.usertables.Where(x => x.username == a.username && x.passwd == a.passwd).FirstOrDefault();
                if (v == null)
                {
                    a.loginerrormsg = "wrong username or password";
                    return View("userlogin", a);
                }
                else
                {
                    Session["username"] = a.username;
                    Session["city"] = a.city;
                    return RedirectToAction("Index","User");
                }
            }
          
        }
       

    }
}