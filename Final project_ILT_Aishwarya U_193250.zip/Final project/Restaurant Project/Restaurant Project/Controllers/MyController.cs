﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Restaurant_Project.Models;
using System.IO;

namespace Restaurant_Project.Controllers
{
    public class MyController : Controller
    {
        // GET: My
        int id;
        public ActionResult addRdetails()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CreateNew(HttpPostedFileBase pbase)
        {
            string rname = Request.Form["rname"];
            string rbranch = Request.Form["rbranch"];
            string rcity = Request.Form["rcity"];
            BinaryReader brd =
                         new BinaryReader(pbase.InputStream);
            byte[] bt = brd.ReadBytes((Int32)
                pbase.InputStream.Length);
            RestaurantDBEntities obj = new RestaurantDBEntities();
            restaurant r1 = new restaurant();
            r1.rname = rname;
            r1.rbranch = rbranch;
            r1.rcity = rcity;
            r1.rimage = bt;
            obj.restaurants.Add(r1);
            obj.SaveChanges();
            //  return View("ShowImage", obj.players.ToList());
            return RedirectToAction("adminedit", "Home");
        }

        public ActionResult existingcity()
        {
            restaurant r = new restaurant();
            using (RestaurantDBEntities db = new RestaurantDBEntities())
            {
                r.restaurantcollection = db.restaurants.ToList<restaurant>();
                r.citycollection = db.restaurants.ToList<restaurant>();
            }
            return View(r);
        }
        [HttpPost]
        public ActionResult CreateNew1(HttpPostedFileBase pbase)
        {
            string rname = Request.Form["rname"];
            string rbranch = Request.Form["rbranch"];
            string rcity = Request.Form["rcity"];
            BinaryReader brd =
                         new BinaryReader(pbase.InputStream);
            byte[] bt = brd.ReadBytes((Int32)
                pbase.InputStream.Length);
            RestaurantDBEntities obj = new RestaurantDBEntities();
            restaurant r1 = new restaurant();
            r1.rname = rname;
            r1.rbranch = rbranch;
            r1.rcity = rcity;
            r1.rimage = bt;
            obj.restaurants.Add(r1);
            obj.SaveChanges();
            //  return View("ShowImage", obj.players.ToList());
            return RedirectToAction("adminedit", "Home");
        }

        public ActionResult selectcity()
        {
            restaurant r = new restaurant();
            using (RestaurantDBEntities db = new RestaurantDBEntities())
            {
                r.branchcollection = db.restaurants.ToList<restaurant>();
                r.citycollection = db.restaurants.ToList<restaurant>();
            }
            return View(r);
        }


        public ActionResult showcitywise(restaurant a)
        {
            RestaurantDBEntities db = new RestaurantDBEntities();
            var v = from b in db.restaurants where b.rcity == a.rcity select b;
            return View("show", v.ToList());
        }


        public ActionResult show()
        {
            return View();
        }

        public ActionResult edit(int rid)
        {
            id = rid;
            RestaurantDBEntities db = new RestaurantDBEntities();
            restaurant r = db.restaurants.ToList().FirstOrDefault(i => i.rid == id);
            TempData["data"] = id;
            return View(r);

        }
        [HttpPost]
        public ActionResult update(HttpPostedFileBase pbase)
        {
            //  int rid = id;
            int rid = (int)TempData["data"];
            string rname = Request.Form["rname"];
            string rbranch = Request.Form["rbranch"];
            string rcity = Request.Form["rcity"];
            BinaryReader brd =
                         new BinaryReader(pbase.InputStream);
            byte[] bt = brd.ReadBytes((Int32)
                pbase.InputStream.Length);
            RestaurantDBEntities obj = new RestaurantDBEntities();
            foreach (var item in obj.restaurants.ToList())
            {
                if (item.rid == rid)
                {
                    item.rname = rname;
                    item.rbranch = rbranch;
                    item.rcity = rcity;
                    item.rimage = bt;
                }
            }
            obj.SaveChanges();
            return View("show", obj.restaurants.ToList());
        }
        public ActionResult showlocationwise(restaurant a)
        {
            RestaurantDBEntities db = new RestaurantDBEntities();
            var v = from b in db.restaurants where b.rbranch == a.rbranch select b;
            return View("show", v.ToList());
        }

        public ActionResult delete(int rid)
        {
            id = rid;
            RestaurantDBEntities db = new RestaurantDBEntities();
            restaurant r = db.restaurants.ToList().FirstOrDefault(i => i.rid == id);
            db.restaurants.Remove(r);
            db.SaveChanges();


            return View("show", db.restaurants.ToList());
        }

        public ActionResult menu()
        {
            restaurant r = new restaurant();
            using (RestaurantDBEntities db = new RestaurantDBEntities())
            {
                r.idcollection = db.restaurants.ToList<restaurant>();
               
            }
            return View(r);
        }
        [HttpPost]
        public ActionResult save(HttpPostedFileBase pbase)
        {
            string fname = Request.Form["fname"];
            string ftype = Request.Form["ftype"];
            int fprice = int.Parse(Request.Form["fprice"]);
            int rid = int.Parse(Request.Form["rid"]);
            BinaryReader brd =
                         new BinaryReader(pbase.InputStream);
            byte[] bt = brd.ReadBytes((Int32)
                pbase.InputStream.Length);
            RestaurantDBEntities obj = new RestaurantDBEntities();
            menu r1 = new menu();
            r1.fname = fname;
            r1.fimage = bt;
            r1.ftype = ftype;
            r1.fprice = fprice;
            r1.rid = rid;
            obj.menus.Add(r1);
            obj.SaveChanges();
            //  return View("ShowImage", obj.players.ToList());
            return RedirectToAction("adminedit", "Home");
        }

        public ActionResult showmenu()
        {
            RestaurantDBEntities db = new RestaurantDBEntities();
            return View(db.menus.ToList());
        }
      
           
           
        
            public ActionResult editmenu(int fid)
             {
          
             id = fid;
            RestaurantDBEntities db = new RestaurantDBEntities();
            menu r = db.menus.ToList().FirstOrDefault(i => i.fid == id);
            TempData["data"] = id;
            return View(r);

              }
        [HttpPost]
        public ActionResult updatemenu(HttpPostedFileBase pbase)
        {
            //  int rid = id;
            int fid = (int)TempData["data"];
            string fname = Request.Form["fname"];
            string ftype = Request.Form["ftype"];
            int fprice = int.Parse(Request.Form["fprice"]);
            int rid = int.Parse(Request.Form["rid"]);
            BinaryReader brd =
                         new BinaryReader(pbase.InputStream);
            byte[] bt = brd.ReadBytes((Int32)
                pbase.InputStream.Length);
            RestaurantDBEntities obj = new RestaurantDBEntities();
            foreach (var item in obj.menus.ToList())
            {
                if (item.fid == fid)
                {
                    item.fname = fname;
                    item.fimage = bt;
                    item.ftype = ftype;
                    item.fprice = fprice;
                    item.rid = rid;
                }
            }
            obj.SaveChanges();
            return View("showmenu",obj.menus.ToList());
        }

        public ActionResult deletemenu(int fid)
        {
            id = fid;
            RestaurantDBEntities db = new RestaurantDBEntities();
            menu r = db.menus.ToList().FirstOrDefault(i => i.fid == id);
            db.menus.Remove(r);
            db.SaveChanges();
            return View("showmenu", db.menus.ToList());
        }
    }
}