﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Restaurant_Project.Models;

namespace Restaurant_Project.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        public ActionResult Index()
        {
            RestaurantDBEntities db = new RestaurantDBEntities();
            string city = Session["city"].ToString();
            var v = from a in db.restaurants  where a.rcity == city select a;
            return View("showloc", v.ToList());
        }

        public ActionResult showrestaurant()
        {
            RestaurantDBEntities db = new RestaurantDBEntities();
            string city = Session["city"].ToString();
            var v = from a in db.restaurants where a.rcity == city select a;
            return View(v.ToList());
        }

        public ActionResult loc(string rname)
        {
            TempData["rname"] = rname;
            RestaurantDBEntities db = new RestaurantDBEntities();
            string city = Session["city"].ToString();
            var v = from a in db.restaurants where a.rcity == city && a.rname == rname select a;
            return View("showloc", v.ToList());
           
        }
        public ActionResult showloc()
        {
           // string rname = TempData["rname"] as string;
            RestaurantDBEntities db = new RestaurantDBEntities();
            string city = Session["city"].ToString();
            var v = from a in db.restaurants where a.rcity == city  select a;
            return View(v.ToList());

        }
        public ActionResult menu(int rid)
        {
            Session["data"] = rid;
            RestaurantDBEntities db = new RestaurantDBEntities();
            var v = from a in db.menus where a.rid == rid select a;
            return View("showusermenu", v.ToList());
        }

        public ActionResult showusermenu()
        {
            //int rid = (int)TempData["data"];
            //RestaurantDBEntities db = new RestaurantDBEntities();
            //var v = from a in db.menus where a.rid == rid select a;
            return View();
        }

        public ActionResult add(int fid)
        {
           
            RestaurantDBEntities db = new RestaurantDBEntities();
            menu r = db.menus.ToList().FirstOrDefault(i => i.fid == fid);
            cart c = new cart();
           
                c.userid = Session["username"] as string;
                c.rid = r.rid;
                c.item = r.fname;
                c.price = r.fprice;
                db.carts.Add(c);
                db.SaveChanges();
           int rid = (int)Session["data"];
            Session["rid"] = rid;
         
            var v = from a in db.menus where a.rid == rid select a;
            return View("showusermenu",v.ToList());
        }

        public ActionResult showcart()
        {
             RestaurantDBEntities db = new RestaurantDBEntities();
            var v = from a in db.carts select a;
            return View(v.ToList());
        }

        public JsonResult total()
        {
            RestaurantDBEntities db = new RestaurantDBEntities();
         //   var v = from a in db.carts select new { int total = sum(a.price) }
             var Sum = (from e in db.carts

                              select e.price).Sum();
            TempData["total"] = Sum;
            return Json(Sum.ToString());
        }

        //public ActionResult deletecart(int cid)
        //{
        //    RestaurantDBEntities db = new RestaurantDBEntities();
        //    cart r = db.carts.ToList().FirstOrDefault(i => i.cid == cid);
        //    db.carts.Remove(r);
        //    db.SaveChanges();


        //    return View("showcart", db.carts.ToList());
        //}

        public JsonResult order()
        {

            RestaurantDBEntities db = new RestaurantDBEntities();
            var v = from a in db.carts select a;
            foreach(var item in v)
            {
                ordered o = new ordered();
                o.userid = item.userid;
                o.rid = item.rid;
                o.orders = item.item;
                o.total = (int)TempData["total"];
                db.ordereds.Add(o);
            } 
            db.SaveChanges();
            var w = from b in db.carts select b;
          foreach(var item in w)
            {
                cart r = db.carts.ToList().FirstOrDefault(i => i.cid == item.cid);
                db.carts.Remove(r);

            }
            db.SaveChanges();
            return Json("ORDER PLACED SUCCESSFULLY");


        }
        public ActionResult history()
        {
            string username = Session["username"].ToString();
            RestaurantDBEntities db = new RestaurantDBEntities();
            var v = from a in db.ordereds where a.userid == username select a;

            return View(v);
        }

        public ActionResult back()
        {
            int rid = (int)Session["rid"];
            RestaurantDBEntities db = new RestaurantDBEntities();
            var v = from a in db.menus where a.rid == rid select a;
            return View("showusermenu", v.ToList());

        }

        public JsonResult Delete(int id)
        {
            RestaurantDBEntities db = new RestaurantDBEntities();
            foreach (var item in db.carts.ToList())
            {
                if (item.cid == id)
                    db.carts.Remove(item);
                db.SaveChanges();
            }
            return Json("Deleted Successfully");
        }
        public ActionResult refresh()
        {
            RestaurantDBEntities db = new RestaurantDBEntities();
            return View("showcart", db.carts.ToList());
        }
    }
}