﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Restaurant_Project.Models
{
    public class menuitem
    {
        public int fid { get; set; }
        public string fname { get; set; }
        public byte[] fimage { get; set; }
        public string ftype { get; set; }
        public Nullable<int> fprice { get; set; }
        public Nullable<int> rid { get; set; }

        public virtual restaurant restaurant { get; set; }
    
        public HttpPostedFileWrapper ImageFile { get; set; }
        [NotMapped]
        public List<restaurant> idcollection { get; set; }

    }
}