﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace iccworldcup
{
    public partial class loginhome : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection();
        DataSet ds = new DataSet();
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter ad = new SqlDataAdapter();
        public loginhome()
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=worldcup;Integrated Security=True");
            con.Open();
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            lblErrorMessage.Visible = false;
            lblErrorMessage0.Visible = false;

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            cmd.CommandText = "select * from login where username='" + txtun.Text + "' and pw='" + txtpw.Text + "'";
            cmd.Connection = con;
            ad.SelectCommand = cmd;
            ad.Fill(ds, "login");
            if(ds.Tables[0].Rows.Count > 0)
            {
                //lblErrorMessage0.Visible = true;
                Response.Redirect("Add.aspx");

            }
            else
            {
                lblErrorMessage.Visible = true;
            }

            //using (con)
            //{
            //    string query = "select count(1) from login where username=@username and pw=@pw";
            //    cmd = new SqlCommand(query, con);
            //    cmd.Parameters.Add("@username", SqlDbType.VarChar, 50).Value
            //                 = txtun.Text;
            //    cmd.Parameters.Add("@pw", SqlDbType.VarChar, 50).Value
            //                       = txtpw.Text;

            //    cmd.ExecuteNonQuery();
            //}

        }
    }
}