﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace iccworldcup
{
    public partial class usershowfixtures : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection();
        DataSet ds = new DataSet();
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter ad = new SqlDataAdapter();
        string ctn;
        public usershowfixtures()
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=worldcup;Integrated Security=True");
            con.Open();
        }

        protected void LoadGrid()
        {

            ds = new DataSet();

            ad = new SqlDataAdapter("select * from fixtures where countryname_1 ='" + ctn + "' or countryname_2 ='" + ctn + "'", con);

            ad.Fill(ds);

            GridView1.DataSource = ds
                    .Tables[0];
            GridView1.DataBind();
        }
        protected void LoadGrid1()
        {
            string countryname = Request.QueryString["cont"];
            ctn = countryname;
            ds = new DataSet();

            ad = new SqlDataAdapter("select * from players where countryname ='"+ctn+"'", con);

            ad.Fill(ds);

            GridView2.DataSource = ds
                    .Tables[0];
            GridView2.DataBind();

        }
      
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack == false)
            {
                LoadGrid1();
                LoadGrid();
            }
            GridView1.Visible = false;
        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
        //    if (e.Row.RowType == DataControlRowType.DataRow)
        //    {
        //        DataRowView dr = (DataRowView)e.Row.DataItem;
        //        string imageUrl = "data:image/jpg;base64," + Convert.ToBase64String((byte[])dr["playerimg"]);
        //        (e.Row.FindControl("Image1") as Image).ImageUrl = imageUrl;
        //    }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           

        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            
            
            GridView1.Visible = true;
        }

        protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRowView dr = (DataRowView)e.Row.DataItem;
                string imageUrl = "data:image/jpg;base64," + Convert.ToBase64String((byte[])dr["playerimg"]);
                (e.Row.FindControl("Image1") as Image).ImageUrl = imageUrl;
            }
        }
    }
}