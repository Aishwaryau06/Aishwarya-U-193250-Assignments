﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace iccworldcup
{
    public partial class addfixtures : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection();
        DataSet ds = new DataSet();
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter ad = new SqlDataAdapter();
        public addfixtures()
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=worldcup;Integrated Security=True");
            con.Open();
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack == false)
            {

                cmbc1.Items.Clear();
                string s = "select * from country";
                ad = new SqlDataAdapter(s, con);
                ds = new DataSet();
                ad.Fill(ds);
                foreach (DataRow item in ds.Tables[0].Rows)
                {
                    cmbc1.Items.Add(item[0].ToString());
                }
                cmbc2.Items.Clear();
                 s = "select * from country";
                ad = new SqlDataAdapter(s, con);
                ds = new DataSet();
                ad.Fill(ds);
                foreach (DataRow item in ds.Tables[0].Rows)
                {
                    cmbc2.Items.Add(item[0].ToString());
                }
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try { 

            string sql = @"insert into fixtures
            values(@matchno,@countryname_1 ,@matchdate,@starttime,@cityname,@stadium,@countryname_2,@winner,@typeofmatch )";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.Add("@matchno", SqlDbType.Int, 50).Value
       = txtno.Text;
            cmd.Parameters.Add("@countryname_1", SqlDbType.VarChar, 50).Value
                               = cmbc1.Text;
            cmd.Parameters.Add("@matchdate", SqlDbType.Date, 50).Value
                                = txtmd.Text;
            cmd.Parameters.Add("@starttime", SqlDbType.Time,50).Value
                               = txtsd.Text;
            cmd.Parameters.Add("@cityname", SqlDbType.VarChar, 50).Value
                               = txtcn.Text;
            cmd.Parameters.Add("@stadium", SqlDbType.VarChar, 50).Value
                              = txtstad.Text;
            cmd.Parameters.Add("@countryname_2", SqlDbType.VarChar, 50).Value
                             = cmbc2.Text;
             cmd.Parameters.Add("@winner", SqlDbType.VarChar, 50).Value
                            = txtwin.Text;
                cmd.Parameters.Add("@typeofmatch", SqlDbType.VarChar, 50).Value
                           = txttom.Text;
                cmd.ExecuteNonQuery();
            Response.Write("<script>alert('Record Has Been saved Successfully');</script>");
            txtno.Text = " ";

            txtcn.Text = " ";
            txtmd.Text = " ";
            txtsd.Text = " ";
            //cmbname.Text = " ";
            txtstad.Text = " ";
                txttom.Text = " ";
                txtwin.Text = " ";


            }
            catch (Exception ex)
                    {
                        Response.Write(ex.Message);
                    }
}

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Add.aspx");
        }
    }
}