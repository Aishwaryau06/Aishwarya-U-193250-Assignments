﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


namespace iccworldcup
{
    public partial class addcountry : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection();
        DataSet ds = new DataSet();
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter ad = new SqlDataAdapter();
        public addcountry()
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=worldcup;Integrated Security=True");
            con.Open();
        }
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {

                FileUpload img = (FileUpload)txtimg;
                Byte[] imgByte = null;
                if (img.HasFile && img.PostedFile != null)
                {
                    HttpPostedFile file = txtimg.PostedFile;
                    imgByte = new byte[file.ContentLength];
                    file.InputStream.Read(imgByte, 0, file.ContentLength);


                }

                string sql = @"insert into country
            values(@countryname,@winneryear,@countryflag,@one_day_ranking,@total_matches_played,@total_points,@net_runrate)";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.Add("@countryname", SqlDbType.VarChar, 50).Value
                    = txtname.Text;
                cmd.Parameters.Add("@winneryear", SqlDbType.Int, 50).Value
                                   = txtwin.Text;
                cmd.Parameters.Add("@countryflag", SqlDbType.Image, 50).Value
                                    = imgByte;
                cmd.Parameters.Add("@one_day_ranking", SqlDbType.Int).Value
                                   = txtrank.Text;
                cmd.Parameters.Add("@total_matches_played", SqlDbType.Int, 50).Value
                                   = txtplayed.Text;
                cmd.Parameters.Add("@total_points", SqlDbType.Int, 50).Value
                                  = txtpoints.Text;
                cmd.Parameters.Add("@net_runrate", SqlDbType.Float, 50).Value
                                  = txtrun.Text;
                cmd.ExecuteNonQuery();
                Response.Write("<script>alert('Record Has Been saved Successfully');</script>");
                txtname.Text = " ";
           
                txtpoints.Text = " ";
                txtrank.Text = " "; 
                txtrun.Text = " ";
                txtwin.Text = " ";
                txtplayed.Text = " ";
            }
            catch(Exception ex)
            {
                Response.Write(ex.Message);
            }
           
            }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Add.aspx");
        }
    }
    }
