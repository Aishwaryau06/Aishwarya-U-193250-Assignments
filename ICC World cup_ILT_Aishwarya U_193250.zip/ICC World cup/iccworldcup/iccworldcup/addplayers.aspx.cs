﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace iccworldcup
{
    public partial class addplayers : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection();
        DataSet ds = new DataSet();
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter ad = new SqlDataAdapter();
        public addplayers()
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=worldcup;Integrated Security=True");
            con.Open();
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack == false)
            {

                cmbname.Items.Clear();
                string s = "select * from country";
                ad = new SqlDataAdapter(s, con);
                ds = new DataSet();
                ad.Fill(ds);
                foreach (DataRow item in ds.Tables[0].Rows)
                {
                    cmbname.Items.Add(item[0].ToString());
                }
            }

            }



        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            try
            {

                FileUpload img = (FileUpload)txtimg;
                Byte[] imgByte = null;
                if (img.HasFile && img.PostedFile != null)
                {
                    HttpPostedFile file = txtimg.PostedFile;
                    imgByte = new byte[file.ContentLength];
                    file.InputStream.Read(imgByte, 0, file.ContentLength);


                }

                string sql = @"insert into players
            values(@playername ,@dob ,@playerimg,@dod,@battinghand,@countryname,@majorrole )";
                SqlCommand cmd = new SqlCommand(sql, con);
                        cmd.Parameters.Add("@playername", SqlDbType.VarChar, 50).Value
                   = txtname.Text;
                        cmd.Parameters.Add("@dob", SqlDbType.Date, 50).Value
                                           = txtdob.Text;
                        cmd.Parameters.Add("@playerimg", SqlDbType.Image, 50).Value
                                            = imgByte;
                        cmd.Parameters.Add("@dod", SqlDbType.Date).Value
                                           = txtdod.Text;
                        cmd.Parameters.Add("@battinghand", SqlDbType.VarChar, 50).Value
                                           = txtbh.Text;
                        cmd.Parameters.Add("@countryname", SqlDbType.VarChar, 50).Value
                                          = cmbname.Text;
                        cmd.Parameters.Add("@majorrole", SqlDbType.VarChar, 50).Value
                                         = txtmr.Text;
                        cmd.ExecuteNonQuery();
                        Response.Write("<script>alert('Record Has Been saved Successfully');</script>");
                        txtname.Text = " ";

                        txtdob.Text = " ";
                        txtbh.Text = " ";
                        txtmr.Text = " ";
                        //cmbname.Text = " ";
                        txtdod.Text = " ";
                    }
                    catch (Exception ex)
                    {
                        Response.Write(ex.Message);
                    }
                }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Add.aspx");
        }
    }
    }
