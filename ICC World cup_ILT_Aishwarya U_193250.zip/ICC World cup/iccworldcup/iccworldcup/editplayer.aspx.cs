﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace iccworldcup
{
    public partial class editplayer : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection();
        DataSet ds = new DataSet();
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter ad = new SqlDataAdapter();
        public editplayer()
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=worldcup;Integrated Security=True");
            con.Open();
        }




        protected void LoadGrid()
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select * from players", con);

            ad.Fill(ds);

            GridView1.DataSource = ds
                    .Tables[0];
            GridView1.DataBind();
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack == false)
            {
                LoadGrid();
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowDataBound1(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRowView dr = (DataRowView)e.Row.DataItem;
                string imageUrl = "data:image/jpg;base64," + Convert.ToBase64String((byte[])dr["playerimg"]);
                (e.Row.FindControl("Image1") as Image).ImageUrl = imageUrl;
            }

        }

        protected void GridView1_RowEditing1(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            LoadGrid();
           
        }
        protected void GridView1_RowUpdating1(object sender, GridViewUpdateEventArgs e)
        {
           
            int index = e.RowIndex;
            string playername = (GridView1.Rows[index].FindControl("playername") as Label).Text;


            DateTime dob =DateTime.Parse( (GridView1.Rows[index]
                            .FindControl("dob") as TextBox).Text);
           

            FileUpload img = (FileUpload)(GridView1.Rows[index]
                                  .FindControl("playerimg") as FileUpload);
            Byte[] playerimg = null;
            if (img.HasFile && img.PostedFile != null)
            {
                HttpPostedFile file = (GridView1.Rows[index]
                                  .FindControl("playerimg") as FileUpload).PostedFile;
                playerimg = new byte[file.ContentLength];
                file.InputStream.Read(playerimg, 0, file.ContentLength);


            }

            DateTime dod = DateTime.Parse((GridView1.Rows[index]
                            .FindControl("dod") as TextBox).Text);

            string battinghand = ((GridView1.Rows[index]
                                      .FindControl("battinghand") as TextBox).Text);

            string countryname = (GridView1.Rows[index]
                                      .FindControl("countryname") as TextBox).Text;

            string majorrole = (GridView1.Rows[index]
                                      .FindControl("majorrole") as TextBox).Text;


            string sql = "update players set dob=@dob,playerimg=@playerimg,dod=@dod,battinghand=@battinghand," +
                "countryname=@countryname,majorrole=@majorrole  where playername=@playername";
            cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@playername",playername);
            cmd.Parameters.AddWithValue("@dob",dob);
            cmd.Parameters.AddWithValue("@playerimg",playerimg);
            cmd.Parameters.AddWithValue("@dod",dod);
            cmd.Parameters.AddWithValue("@battinghand",battinghand);
            cmd.Parameters.AddWithValue("@countryname",countryname);
            cmd.Parameters.AddWithValue("@majorrole",majorrole);


            cmd.ExecuteNonQuery();
            GridView1.EditIndex = -1;

            LoadGrid();

        }


        protected void GridView1_RowCancelingEdit1(object sender, GridViewCancelEditEventArgs e)
        {

            GridView1.EditIndex = -1;
            LoadGrid();

        }

        protected void GridView1_RowDeleting1(object sender, GridViewDeleteEventArgs e)
        {
            int i = e.RowIndex;
            string playername = (GridView1.Rows[i].FindControl("playername")
                            as Label).Text;
           
            string sql = @"delete from players where playername=@playername";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            GridView1.EditIndex = -1;
            LoadGrid();

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            Response.Redirect("Add.aspx");
        }

        protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
        {

        }
    }
}