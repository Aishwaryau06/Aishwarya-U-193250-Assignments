﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace iccworldcup
{
    public partial class home : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection();
        DataSet ds = new DataSet();
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter ad = new SqlDataAdapter();
        public home()
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=worldcup;Integrated Security=True");
            con.Open();
        }

        protected void LoadGrid()
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select countryname,countryflag,total_matches_played,total_points,net_runrate from country order by total_points desc", con);

            ad.Fill(ds);

            GridView1.DataSource = ds
                    .Tables[0];
            GridView1.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack == false)
            {
                LoadGrid();
            }

        }

        //protected void Button1_Click(object sender, EventArgs e)
        //{
        //    Response.Redirect("loginhome.aspx");
        //}

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            //if (e.Row.RowType == DataControlRowType.DataRow)
            //{
            //    DataRowView dr = (DataRowView)e.Row.DataItem;
            //    string imageUrl = "data:image/jpg;base64," + Convert.ToBase64String((byte[])dr["countryflag"]);
            //    (e.Row.FindControl("Image1") as Image).ImageUrl = imageUrl;
            //}

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRowView dr = (DataRowView)e.Row.DataItem;
                string imageUrl = "data:image/jpg;base64," + Convert.ToBase64String((byte[])dr["countryflag"]);
                (e.Row.FindControl("Image2") as Image).ImageUrl = imageUrl;
            }
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int index = e.RowIndex;
            string countryname = (GridView1.Rows[index].FindControl("countryname") as Label).Text;
            Response.Redirect("usershowfixtures.aspx?cont=" + countryname);


        }


    }
}