﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace iccworldcup
{
    public partial class editcountry : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection();
        DataSet ds = new DataSet();
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter ad = new SqlDataAdapter();
        public editcountry()
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=worldcup;Integrated Security=True");
            con.Open();
        }




        protected void LoadGrid()
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select * from country", con);

            ad.Fill(ds);

            GridView1.DataSource = ds
                    .Tables[0];
            GridView1.DataBind();
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack == false)
            {
                LoadGrid();
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRowView dr = (DataRowView)e.Row.DataItem;
                string imageUrl = "data:image/jpg;base64," + Convert.ToBase64String((byte[])dr["countryflag"]);
                (e.Row.FindControl("Image1") as Image).ImageUrl = imageUrl;
            }
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {

            GridView1.EditIndex = e.NewEditIndex;
            LoadGrid();


        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {


            int index = e.RowIndex;
            string countryname = (GridView1.Rows[index].FindControl("countryname") as Label).Text;


            int winneryear = int.Parse((GridView1.Rows[index]
                            .FindControl("winneryear") as TextBox).Text);

         
            FileUpload img = (FileUpload)(GridView1.Rows[index]
                                   .FindControl("countryflag") as FileUpload); 
            Byte[] countryflag = null;
            if (img.HasFile && img.PostedFile != null)
            {
                HttpPostedFile file = (GridView1.Rows[index]
                                   .FindControl("countryflag") as FileUpload).PostedFile;
                countryflag = new byte[file.ContentLength];
                file.InputStream.Read(countryflag, 0, file.ContentLength);


            }

            int one_day_ranking = int.Parse((GridView1.Rows[index]
                            .FindControl("one_day_ranking") as TextBox).Text);

            int total_matches_played = int.Parse((GridView1.Rows[index]
                                      .FindControl("total_matches_played") as TextBox).Text);

            int total_points = int.Parse((GridView1.Rows[index]
                                      .FindControl("total_points") as TextBox).Text);

            float net_runrate = float.Parse((GridView1.Rows[index]
                                      .FindControl("net_runrate") as TextBox).Text);



            string sql = "update country set winneryear=@winneryear,countryflag=@countryflag,one_day_ranking=@one_day_ranking,total_matches_played=@total_matches_played," +
                "total_points=@total_points,net_runrate=@net_runrate  where countryname=@countryname";
            cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@countryname",countryname);
            cmd.Parameters.AddWithValue("@winneryear",winneryear);
            cmd.Parameters.AddWithValue("@countryflag",countryflag);
            cmd.Parameters.AddWithValue("@one_day_ranking",one_day_ranking);
            cmd.Parameters.AddWithValue("@total_matches_played",total_matches_played);
            cmd.Parameters.AddWithValue("@total_points",total_points);
            cmd.Parameters.AddWithValue("@net_runrate",net_runrate);


            cmd.ExecuteNonQuery();
            GridView1.EditIndex = -1;

            LoadGrid();

        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {

            GridView1.EditIndex = -1;
            LoadGrid();


        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int i = e.RowIndex;
            string countryname = (GridView1.Rows[i].FindControl("countryname")
                            as Label).Text;

      
            string sql = @"delete from country where countryname=@countryname";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            GridView1.EditIndex = -1;
            LoadGrid();

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Add.aspx");
        }
    }
}