﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace iccworldcup
{
    public partial class editfixtures : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection();
        DataSet ds = new DataSet();
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter ad = new SqlDataAdapter();
        public editfixtures()
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=worldcup;Integrated Security=True");
            con.Open();
        }
        protected void LoadGrid()
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select * from fixtures", con);

            ad.Fill(ds);

            GridView1.DataSource = ds
                    .Tables[0];
            GridView1.DataBind();
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack == false)
            {
                LoadGrid();
            }


        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {

            GridView1.EditIndex = e.NewEditIndex;
            LoadGrid();

        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

            int index = e.RowIndex;
            string matchno = (GridView1.Rows[index].FindControl("matchno") as Label).Text;


            string countryname_1 = (GridView1.Rows[index]
                            .FindControl("countryname_1") as TextBox).Text;

            string matchdate = (GridView1.Rows[index]
                                   .FindControl("matchdate") as TextBox).Text;

            string starttime = ((GridView1.Rows[index]
                            .FindControl("starttime") as TextBox).Text);

            string cityname = ((GridView1.Rows[index]
                                      .FindControl("cityname") as TextBox).Text);

            string stadium = ((GridView1.Rows[index]
                                      .FindControl("stadium") as TextBox).Text);

            string countryname_2 =((GridView1.Rows[index]
                                      .FindControl("countryname_2") as TextBox).Text);

            string winner =((GridView1.Rows[index]
                                      .FindControl("winner") as TextBox).Text);

            string typeofmatch =((GridView1.Rows[index]
                                      .FindControl("typeofmatch") as TextBox).Text);

         

           
            string sql = "update fixtures set countryname_1=@countryname_1,matchdate=@matchdate,starttime=@starttime,cityname=@cityname," +
                "stadium=@stadium,countryname_2=@countryname_2,winner=@winner,typeofmatch=@typeofmatch   where matchno=@matchno";
            cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@matchno", matchno);
            cmd.Parameters.AddWithValue("@countryname_1",countryname_1);
            cmd.Parameters.AddWithValue("@matchdate",matchdate);
            cmd.Parameters.AddWithValue("@starttime",starttime);
            cmd.Parameters.AddWithValue("@cityname",cityname);
            cmd.Parameters.AddWithValue("@stadium", stadium);
            cmd.Parameters.AddWithValue("@countryname_2",countryname_2);
            cmd.Parameters.AddWithValue("@winner",winner);
            cmd.Parameters.AddWithValue("@typeofmatch", typeofmatch);
           
            cmd.ExecuteNonQuery();
            GridView1.EditIndex = -1;

            LoadGrid();


        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            
                GridView1.EditIndex = -1;
                LoadGrid();

            }

            protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int i = e.RowIndex;
            int matchno =int.Parse((GridView1.Rows[i].FindControl("matchno")
                            as Label).Text);

           
            string sql = @"delete from fixtures where matchno=@matchno";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
            GridView1.EditIndex = -1;
            LoadGrid();

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Add.aspx");
        }
    }
}

        
