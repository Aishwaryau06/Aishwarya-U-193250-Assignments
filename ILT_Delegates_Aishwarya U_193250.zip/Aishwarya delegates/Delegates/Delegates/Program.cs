﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Delegates
{
    public delegate void filter(int[] num);
    class Program
    {
        static void Prime(int[] num)
        {
            Console.WriteLine("Prime ");
            int j;
            bool isprime = true;
            for (int i = 0; i < num.Length; i++)
            {
                for (j = 2; j <= num[i]; j++)
                {
                    if (i != j && i % j == 0)
                    {
                        isprime = false;
                        break;
                    }
                }
                if (isprime)
                {
                    Console.WriteLine(num[i] + " ");
                }
            }

        }

        static void Even(int[] num)
        {
            Console.WriteLine("Even");
            for (int i = 0; i < num.Length; i++)
            {

                if (num[i] % 2 == 0)
                    Console.WriteLine(num[i] + " ");

            }
        }
        static void Odd(int[] num)
        {
            Console.WriteLine("Odd ");
            for (int i = 0; i < num.Length; i++)
            {

                if (num[i] % 2 == 1)
                    Console.WriteLine(num[i] + " ");

            }
        }

        static void Main(string[] args)
        {
            int[] num = { 1, 3, 55, 87, 25, 80, 26, 2, 4, 6 };
            filter a = (t1) => { Prime(t1); };
            filter b = (t1) => { Odd(t1); };
            filter c = (t1) => { Even(t1); };


            void opt(int[] n, filter ft)
            {
                ft(n);
            }
            opt(num, a);
            opt(num, b);
            opt(num, c);
            Console.ReadLine();




        }
    }
}