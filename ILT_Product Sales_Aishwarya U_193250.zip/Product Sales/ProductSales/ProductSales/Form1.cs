﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProductSales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pRODUCTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Product newMDIChild = new Product();

            newMDIChild.MdiParent = this;

            newMDIChild.Show();
        }

        private void sALESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sale newMDIChild = new Sale();

            newMDIChild.MdiParent = this;

            newMDIChild.Show();

        }

        private void sHOWPRODUCTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            show newMDIChild = new show();

            newMDIChild.MdiParent = this;

            newMDIChild.Show();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
