﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProductSales
{
    public partial class show : Form
    {
        public show()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            showDataLayer sdl = new showDataLayer();

            DataSet ds = sdl.Query1();
            dataGridView1.DataSource = ds.Tables[0];

        }

        private void button2_Click(object sender, EventArgs e)
        {
            showDataLayer sdl = new showDataLayer();

            DataSet ds = sdl.Query2();
            dataGridView1.DataSource = ds.Tables[0];

        }

        private void button3_Click(object sender, EventArgs e)
        {
            showDataLayer sdl = new showDataLayer();

            DataSet ds = sdl.Query3();
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void button4_Click(object sender, EventArgs e)
        {
            showDataLayer sdl = new showDataLayer();

            DataSet ds = sdl.Query4();
            dataGridView1.DataSource = ds.Tables[0];

        }

        private void button5_Click(object sender, EventArgs e)
        {
            showDataLayer sdl = new showDataLayer();

            DataSet ds = sdl.Query5();
            dataGridView1.DataSource = ds.Tables[0];

        }

        private void button6_Click(object sender, EventArgs e)
        {
            showDataLayer sdl = new showDataLayer();

            DataSet ds = sdl.Query6();
            dataGridView1.DataSource = ds.Tables[0];

        }

        private void button7_Click(object sender, EventArgs e)
        {
            showDataLayer sdl = new showDataLayer();

            DataSet ds = sdl.Query7();
            dataGridView1.DataSource = ds.Tables[0];

        }

        private void show_Load(object sender, EventArgs e)
        {

        }
    }
}
