﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace ProductSales
{
    public partial class Sale : Form
    {
        SqlConnection con;
        DataSet ds;
        SqlCommand cmd;
        SqlDataAdapter ad;
        public Sale()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PSDataLayer cdl = new PSDataLayer();
            cdl.AddnewSale(int.Parse(txtID.Text), int.Parse(cmbpid.Text), int.Parse(txtyear.Text), int.Parse(txtqual.Text),
                int.Parse(txtprice.Text));
            MessageBox.Show("inserted successfully");
            txtID.Text = "";
            cmbpid.Text = "";
            txtyear.Text = "";
            txtqual.Text = "";
            txtprice.Text = "";


        }

        private void Sale_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ProductSale;Integrated Security=True");
            con.Open();
            string s = "select * from PRODUCTS";
            ad = new SqlDataAdapter(s, con);
            ds = new DataSet();
            ad.Fill(ds);
            foreach (DataRow item in ds.Tables[0].Rows)
            {
                cmbpid.Items.Add(item[0].ToString());
            }
        }
    }
}
