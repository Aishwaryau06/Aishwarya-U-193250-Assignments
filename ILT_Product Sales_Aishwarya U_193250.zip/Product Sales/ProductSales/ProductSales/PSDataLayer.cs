﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace ProductSales
{
    class PSDataLayer
    {
        SqlConnection con;
        DataSet ds;
        SqlCommand cmd;
        SqlDataAdapter ad;

        public PSDataLayer()
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ProductSale;Integrated Security=True");
            con.Open();
        }
        public void AddnewProduct(int pid, string pname)
        {
            string sql = "InsertPData";
            cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@PRODUCT_ID", SqlDbType.Int, 4).Value
                = pid;
            cmd.Parameters.Add("@PRODUCT_NAME", SqlDbType.VarChar, 50).Value
                               = pname;
           

            cmd.ExecuteNonQuery();

        }

        public void AddnewSale(int sid,int pid,int year,int quality,int price)
        {
            string sql = "InsertSData";
            cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@SALE_ID", SqlDbType.Int, 4).Value
               = sid;
            cmd.Parameters.Add("@PRODUCT_ID", SqlDbType.Int, 4).Value
                = pid;
            cmd.Parameters.Add("@YEAR", SqlDbType.Int, 4).Value
                               = year;
            cmd.Parameters.Add("@Quantity", SqlDbType.Int, 4).Value
                               = quality;
            cmd.Parameters.Add("@PRICE", SqlDbType.Int, 4).Value
                              = price;



            cmd.ExecuteNonQuery();

        }

    }
}