﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace ProductSales
{
    class showDataLayer
    {
        SqlConnection con;
        DataSet ds;
        SqlCommand cmd;
        SqlDataAdapter ad;

        public showDataLayer()
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=ProductSale;Integrated Security=True");
            con.Open();
        }
        public DataSet Query1()
        {
           ds = new DataSet();

            ad = new SqlDataAdapter("select p.PRODUCT_NAME from PRODUCTS p   where  p.PRODUCT_ID not in (select distinct PRODUCT_ID from SALES)", con);
            ad.Fill(ds);
            return ds;
        }

        public DataSet Query2()
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select p.PRODUCT_NAME from PRODUCTS p,SALES S_2012,SALES S_2011 " +
                "where p.PRODUCT_ID = S_2012.PRODUCT_ID and S_2012.YEAR = 2012 and S_2011.YEAR = 2011 " +
                "and S_2012.PRODUCT_ID = S_2011.PRODUCT_ID and S_2012.QUANTITY < S_2011.QUANTITY", con);
            ad.Fill(ds);
            return ds;
        }

        public DataSet Query3()
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select p.PRODUCT_NAME, sum( s.QUANTITY*s.PRICE ) TOTAL_SALES " +
                "from   PRODUCTS p left outer join SALES s on     (p.PRODUCT_ID = s.PRODUCT_ID) " +
                "group by p.PRODUCT_NAME", con);
            ad.Fill(ds);
            return ds;
        }

        public DataSet Query4()
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select p.PRODUCT_NAME,s.YEAR,s.QUANTITY " +
                "from PRODUCTS p,SALES s where p.PRODUCT_ID = s.PRODUCT_ID  and" +
                " s.QUANTITY >(select avg(QUANTITY) from SALES s1 where s1.PRODUCT_ID = s.PRODUCT_ID)", con);
            ad.Fill(ds);
            return ds;
        }
        public DataSet Query5()
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select si.YEAR,si.QUANTITY IPHONE_QUANT,ss.QUANTITY SAM_QUANT,si.PRICE IPHONE_PRICE,ss.PRICE SAM_PRICE" +
                " from PRODUCTS pi,SALES si,PRODUCTS ps,SALES ss" +
                " where pi.PRODUCT_ID = si.PRODUCT_ID and ps.PRODUCT_ID = ss.PRODUCT_ID and pi.PRODUCT_NAME = 'IPhone' " +
                "and ps.PRODUCT_NAME = 'Samsung' and si.YEAR = ss.YEAR", con);
            ad.Fill(ds);
            return ds;
        }

        public DataSet Query6()
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select YEAR,count(*) as NUM_PRODUCTS from SALES group by YEAR", con);
            ad.Fill(ds);
            return ds;
        }
        public DataSet Query7()
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select PRODUCT_NAME,YEAR from(select p.PRODUCT_NAME,s.YEAR,rank() " +
                "over (partition by s.YEAR order by S.QUANTITY desc)rnk " +
                "from PRODUCTS p,SALES s where p.PRODUCT_ID = s.PRODUCT_ID) a where rnk= 1;", con);
            ad.Fill(ds);
            return ds;
        }

    }
}
