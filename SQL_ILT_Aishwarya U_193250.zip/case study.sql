1.Display passenger name who has a 'e' as second letter in their name.

 select passname from passenger 
 where passname like '_e%';

2.Display the name of the youngest passenger.
select passname from passenger 
where passdob=(select max(passdob) max from passenger);

3. Display the name of the passenger, date of birth and age.

  SELECT passname,passdob,DATEDIFF(hour,passdob,GETDATE())/8766 AS Age FROM passenger;

4.Display the number of flights leaving Kolkata.
 SELECT COUNT(*) numofflights FROM FLIGHT 
 WHERE FLIGHTSOURCE='KOL';

6. Display the name of the city which has flight source but no destination.

 SELECT flightsource FROM flight
where
   flightdest is null ;

7. Display the dates on which flight 1 and 4 is flying.

 SELECT flightdate FROM FLIGHT 
 WHERE flightid=1 OR flightid=4;

 8. Display the number of passenger in each flight. Use column alias
�PassCount�.
SELECT FLIGHTID,COUNT(B.PASSID) PASSCOUNT FROM BOOKING_DETAILS B INNER
 JOIN BOOKING B1 ON B1.BOOKINGID=B.BOOKINGID GROUP BY FLIGHTID;

9. Display the name and date of birth of passengers who are senior citizen (age>=60).

 SELECT PASSNAME,PASSDOB FROM PASSENGER 
 where DATEDIFF(hour,passdob,GETDATE())/8766 >=60;

11. Display the booking id (ticket) and the total cost for the booking. Use column alias �Total Fare�.

 SELECT B.BOOKINGID,F.TICKETCOST as TOTAL_FARE FROM BOOKING B 
 INNER JOIN FLIGHT F ON B.FLIGHTID=F.FLIGHTID;

15. Display flightid with no of booking.

 select flightid,count(*) NO_OF_BOOKINGS from booking group by flightid;



17.Display flights having the same source and destination.
 
 select flightid from flight where flightdest=flightsource;

10.Display the booking id having the highest number of passengers.
 SELECT BOOKINGID FROM BOOKING_DETAILS GROUP BY BOOKINGID HAVING COUNT(PASSID)=
 (
 SELECT MAX(C) FROM 
 (
 SELECT BOOKINGID,COUNT(PASSID) C FROM BOOKING_DETAILS GROUP BY BOOKINGID
 ) a);

14. Display the passenger�s name having more than 1 booking.
  SELECT PASSNAME FROM PASSENGER WHERE PASSID IN 
 (
 SELECT PASSID FROM BOOKING_DETAILS GROUP BY PASSID HAVING COUNT(BOOKINGID)>1
 );

13.Display the city receiving the maximum number of flights.

 select flightdest 
from flight 
group by flightdest 
having count(*)=(select max(c) 
                 from (select count(*) c 
                       from flight 
                       group by flightdest
                     )a
               );


5. Display the name of city where the number of flights leaving and reaching is the same.

 SELECT flightsource FROM 
 (SELECT flightsource,COUNT(*) C1 FROM flight GROUP BY  flightsource)A INNER JOIN 
 (SELECT flightdest,COUNT(*) C2 FROM flight GROUP BY flightdest)B ON A.C1=B.C2 AND  
 A.flightsource=B.flightdest;



 
 
  








   

