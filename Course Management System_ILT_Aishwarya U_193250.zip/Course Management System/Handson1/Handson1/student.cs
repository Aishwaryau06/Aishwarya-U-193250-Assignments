﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Handson1
{
    public partial class student : Form
    {
        public student()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            courseDataLayer cdl = new courseDataLayer();
            cdl.AddnewStudent(txtID.Text, txtName.Text, txtDOB.Text,
                txtcity.Text, txtqual.Text, txtemail.Text, txtphno.Text);
            MessageBox.Show("inserted successfully");
            txtID.Text = "";
            txtName.Text = "";
            txtDOB.Text = "";
            txtcity.Text = "";
            txtqual.Text = "";
            txtemail.Text = "";
            txtphno.Text = "";

        }
    }
}
