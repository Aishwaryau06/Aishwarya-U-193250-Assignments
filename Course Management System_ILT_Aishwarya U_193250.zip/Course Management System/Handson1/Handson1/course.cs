﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Handson1
{
    public partial class course : Form
    {
        public course()
        {
            InitializeComponent();
        }

        private void course_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            courseDataLayer cdl = new courseDataLayer();
            cdl.AddnewCourse(txtID.Text, txtName.Text, txtcat.Text,
               decimal.Parse( txtfee.Text),int.Parse(txtdu.Text));
            MessageBox.Show("inserted successfully");
            txtID.Text = "";
            txtName.Text = "";
            txtcat.Text = "";
            txtfee.Text = "";
            txtdu.Text = "";
          

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtcat_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtfee_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtdu_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
