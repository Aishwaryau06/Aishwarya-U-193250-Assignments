﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Handson1
{
    public partial class batch : Form
    {
        SqlConnection con;
        DataSet ds;
        SqlCommand cmd;
        SqlDataAdapter ad;
        public batch()
        {
            InitializeComponent();
        }

        private void batch_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=coursems;Integrated Security=True");
            con.Open();
          string  s = "select * from course";
            ad = new SqlDataAdapter(s, con);
            ds = new DataSet();
            ad.Fill(ds);
            foreach (DataRow item in ds.Tables[0].Rows)
            {
                cmbcid.Items.Add(item[0].ToString());
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
                courseDataLayer cdl = new courseDataLayer();
                cdl.AddnewBatch(txtid.Text, txtDate.Text, int.Parse(txtstr.Text), cmbcid.Text);

                MessageBox.Show("inserted successfully");
                txtid.Text = "";
                txtDate.Text = "";
                txtstr.Text = "";
                cmbcid.Text = "";
           
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtstr_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void cmbcid_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtid_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
