﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Handson1
{
    public partial class showStudent : Form
    {
        SqlConnection con;
        DataSet ds;
        SqlCommand cmd;
        SqlDataAdapter ad;
        public showStudent()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            showDataLayer sdl = new showDataLayer();
            DataSet ds = sdl.GetAllStudents();
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void showStudent_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=coursems;Integrated Security=True");
            con.Open();
            string s = "select * from student";
            ad = new SqlDataAdapter(s, con);
            ds = new DataSet();
            ad.Fill(ds);
            foreach (DataRow item in ds.Tables[0].Rows)
            {
                cmbsid.Items.Add(item[0].ToString());
            }

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            showDataLayer sdl = new showDataLayer();

            DataSet ds = sdl.Query1(cmbsid.Text);
            dataGridView1.DataSource = ds.Tables[0];

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            showDataLayer sdl = new showDataLayer();

            DataSet ds = sdl.Query2(cmbsid.Text);
            dataGridView1.DataSource = ds.Tables[0];

        }
    }
}
