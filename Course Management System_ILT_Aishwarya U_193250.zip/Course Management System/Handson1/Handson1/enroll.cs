﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Handson1
{
    public partial class enroll : Form
    {
        SqlConnection con;
        DataSet ds;
        SqlCommand cmd;
        SqlDataAdapter ad;
        public enroll()
        {
            InitializeComponent();
        }

        private void enroll_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=coursems;Integrated Security=True");
            con.Open();
            string s = "select * from student";
            ad = new SqlDataAdapter(s, con);
            ds = new DataSet();
            ad.Fill(ds);
            foreach (DataRow item in ds.Tables[0].Rows)
            {
                cmbid.Items.Add(item[0].ToString());
            }

             s = "select * from batch";
            ad = new SqlDataAdapter(s, con);
            ds = new DataSet();
            ad.Fill(ds);
            foreach (DataRow item in ds.Tables[0].Rows)
            {
                cmbbid.Items.Add(item[0].ToString());
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            courseDataLayer cdl = new courseDataLayer();
            cdl.AddnewEnroll(cmbbid.Text, cmbid.Text, txtdate.Text);
            MessageBox.Show("inserted successfully");
            cmbid.Text = "";
            cmbbid.Text = "";
            txtdate.Text = "";
        }
    }
}
