﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Handson1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void addStudentDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            student newMDIChild = new student();
            
            newMDIChild.MdiParent = this;
            
            newMDIChild.Show();
        }

        private void addCouseDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {

            course newMDIChild1 = new course();
           
            newMDIChild1.MdiParent = this;
           
            newMDIChild1.Show();


        }

        private void addBatchDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            batch newMDIChild2 = new batch();
         
            newMDIChild2.MdiParent = this;
            
            newMDIChild2.Show();
        }

        private void addEnrollmentsDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            enroll newMDIChild3= new enroll();
           
            newMDIChild3.MdiParent = this;
           
            newMDIChild3.Show();
        }

        private void showDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void showStudentDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showStudent newMDIChild4 = new showStudent();

            newMDIChild4.MdiParent = this;

            newMDIChild4.Show();

        }

        private void showCourseDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showCourse newMDIChild5 = new showCourse();

            newMDIChild5.MdiParent = this;

            newMDIChild5.Show();

        }

        private void showBatchDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showBatches newMDIChild6 = new showBatches();

            newMDIChild6.MdiParent = this;

            newMDIChild6.Show();


        }

        private void showEnrollmentsDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showEnroll newMDIChild7 = new showEnroll();

            newMDIChild7.MdiParent = this;

            newMDIChild7.Show();

        }
    }
}
