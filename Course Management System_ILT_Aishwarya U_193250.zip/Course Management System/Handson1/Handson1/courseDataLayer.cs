﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Handson1
{
    class courseDataLayer
    {

        SqlConnection con;
        DataSet ds;
        SqlCommand cmd;
        SqlDataAdapter ad;
        public courseDataLayer()
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=coursems;Integrated Security=True");
            con.Open();
        }
        public void AddnewStudent(string sid,string sname,string sdob,string scity,string squal,string semail,string sphone )
        {
            string sql = "InsertSData";
             cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@sid", SqlDbType.Char, 4).Value
                = sid;
            cmd.Parameters.Add("@sname", SqlDbType.VarChar, 50).Value
                               = sname;
            cmd.Parameters.Add("@sdob", SqlDbType.Date, 50).Value
                                = sdob;
            cmd.Parameters.Add("@scity", SqlDbType.VarChar,50).Value
                               = scity;
            cmd.Parameters.Add("@squal", SqlDbType.VarChar, 50).Value
                               = squal;
            cmd.Parameters.Add("@semail", SqlDbType.VarChar, 50).Value
                               = semail;
            cmd.Parameters.Add("@sphone", SqlDbType.VarChar, 50).Value
                               = sphone;

            cmd.ExecuteNonQuery();

        }

        public void AddnewCourse(string courseid, string cname, string ccat ,
            decimal cfee, int cdu)
        {
            string sql = "InsertCData";
            cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@courseid", SqlDbType.Char, 4).Value
                = courseid;
            cmd.Parameters.Add("@coursename", SqlDbType.VarChar, 50).Value
                               = cname;
            cmd.Parameters.Add("@coursecategory", SqlDbType.VarChar, 50).Value
                                = ccat;
            cmd.Parameters.Add("@coursefees", SqlDbType.Decimal, 50).Value
                               = cfee;
            cmd.Parameters.Add("@courseduration", SqlDbType.Int, 50).Value
                               = cdu;
            
            cmd.ExecuteNonQuery();

        }

        public void AddnewBatch(string batchid, string bsdate,
            int bstrength,
           string courseid)
        {
            string sql = "InsertBData";
            cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@batchid", SqlDbType.Char, 4).Value
                = batchid;
            cmd.Parameters.Add("@bsdate", SqlDbType.DateTime, 50).Value
                               = bsdate;
            cmd.Parameters.Add("@bstrength", SqlDbType.Int, 50).Value
                                = bstrength;
            cmd.Parameters.Add("@courseid", SqlDbType.Char, 4).Value
                               = courseid;
           
            cmd.ExecuteNonQuery();

        }
        public void AddnewEnroll(string bid, string sid, string date)
        {
            string sql = "InsertEData";
            cmd = new SqlCommand(sql, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@batchid ", SqlDbType.Char, 4).Value
                = bid;
            cmd.Parameters.Add("@sid ", SqlDbType.Char, 4).Value
               = sid;
           
            cmd.Parameters.Add("@edate ", SqlDbType.Date, 50).Value
                                = date;
         

            cmd.ExecuteNonQuery();
        }


        }
}
