﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Handson1
{
    public partial class showCourse : Form
    {

        SqlConnection con;
        DataSet ds;
        SqlCommand cmd;
        SqlDataAdapter ad;
        public showCourse()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            showDataLayer sdl = new showDataLayer();
            DataSet ds = sdl.GetAllCourses();
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            showDataLayer sdl = new showDataLayer();

            DataSet ds = sdl.Query3(cmbcid.Text);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void showCourse_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=coursems;Integrated Security=True");
            con.Open();
            string s = "select * from course";
            ad = new SqlDataAdapter(s, con);
            ds = new DataSet();
            ad.Fill(ds);
            foreach (DataRow item in ds.Tables[0].Rows)
            {
                cmbcid.Items.Add(item[0].ToString());
            }
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            showDataLayer sdl = new showDataLayer();

            DataSet ds = sdl.Query4();
            dataGridView1.DataSource = ds.Tables[0];

        }
    }
}
