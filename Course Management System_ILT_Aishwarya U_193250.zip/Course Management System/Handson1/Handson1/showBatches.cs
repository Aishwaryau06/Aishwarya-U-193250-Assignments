﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Handson1
{
    public partial class showBatches : Form
    {
        SqlConnection con;
        DataSet ds;
        SqlCommand cmd;
        SqlDataAdapter ad;
        public showBatches()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            showDataLayer sdl = new showDataLayer();
            DataSet ds = sdl.GetAllBatches();
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void showBatches_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=coursems;Integrated Security=True");
            con.Open();
           string s = "select * from batch";
            ad = new SqlDataAdapter(s, con);
            ds = new DataSet();
            ad.Fill(ds);
            foreach (DataRow item in ds.Tables[0].Rows)
            {
                cmbbid.Items.Add(item[0].ToString());
            }

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            showDataLayer sdl = new showDataLayer();

            DataSet ds = sdl.Query5(cmbbid.Text);
            dataGridView1.DataSource = ds.Tables[0];
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            showDataLayer sdl = new showDataLayer();

            DataSet ds = sdl.Query6();
            dataGridView1.DataSource = ds.Tables[0];

        }
    }
}
