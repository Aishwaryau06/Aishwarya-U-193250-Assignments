﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Handson1
{
    class showDataLayer
    {

        SqlConnection con;
        DataSet ds;
        SqlCommand cmd;
        SqlDataAdapter ad;
        public showDataLayer()
        {
            con = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=coursems;Integrated Security=True");
            con.Open();
        }
        public DataSet GetAllStudents()
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select * from student", con);

            ad.Fill(ds);
            return ds;
        }
        public DataSet GetAllCourses()
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select * from course", con);

            ad.Fill(ds);
            return ds;
        }

        public DataSet GetAllBatches()
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select * from batch ", con);

            ad.Fill(ds);
            return ds;
        }

        public DataSet GetAllEnrolls()
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select * from enrollment ", con);

            ad.Fill(ds);
            return ds;
        }
        public DataSet Query1(string sid)
        {
            

           
            ds = new DataSet();
         
            ad = new SqlDataAdapter("select b.batchid,b.bsdate,b.bstrength,b.courseid from batch b join " +
                "enrollment e on b.batchid=e.batchid where e.sid= '"+sid+"'", con);
            ad.Fill(ds);
            return ds;
        }
        public DataSet Query2(string sid)
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select c.courseid,c.coursename,c.coursecategory,c.coursefees,c.courseduration from batch b join enrollment e on b.batchid = e.batchid join course c on c.courseid = b.courseid where e.sid = '"+sid+"' ", con);
            ad.Fill(ds);
            return ds;
        }

        public DataSet Query3(string courseid)
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select * from course  where courseid='"+courseid+"'", con);
            ad.Fill(ds);
            return ds;
        }
        public DataSet Query4()
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select c1.courseid, v.cnt,v.cnt * c1.coursefees" +
                "  as 'Total_Revenue' from (select batchid,count(*) as cnt from" +
                " enrollment group by batchid)as v " +
                "inner join batch b1 on v.batchid = b1.batchid inner join course c1 on c1.courseid = b1.courseid ", con);
            ad.Fill(ds);
            return ds;
        }
        public DataSet Query5(string batchid)
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select * from batch where batchid='"+batchid+"'", con);
            ad.Fill(ds);
            return ds;
        }
        public DataSet Query6()
        {
            ds = new DataSet();

            ad = new SqlDataAdapter("select b.batchid, t.cnt, b.bstrength - t.cnt as 'vacant' " +
                "from(select batchid, count(*) as cnt from enrollment group by batchid)t " +
                "inner join batch b on b.batchid = t.batchid", con);
            ad.Fill(ds);
            return ds;
        }

    }
}
