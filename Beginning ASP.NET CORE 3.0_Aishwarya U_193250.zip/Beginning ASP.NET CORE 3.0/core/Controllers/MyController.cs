using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using core.Models;

namespace core.Controllers
{
    public class MyController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Calculate()
        {
            float res=0;
            float num1=float.Parse(Request.Form["num1"]);
            float num2=float.Parse(Request.Form["num2"]);
            string op=Request.Form["opr"];
            if(op=="Add"){
                res=num1+num2;
            }
            else if(op=="Subract"){
                res=num1-num2;
            }
            else if(op=="Multiply"){
                res=num1*num2;
            }
            else if(op=="Divide"){
                res=num1/num2;
            }
            ViewBag.rest=res;
            return View();
        }
    }
}
       