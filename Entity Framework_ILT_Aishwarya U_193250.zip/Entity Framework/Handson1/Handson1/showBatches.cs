﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Handson1
{
    public partial class showBatches : Form
    {
        public showBatches()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            coursemsEntities obj = new coursemsEntities();

            dataGridView1.DataSource = obj.batches.ToList();
        }

        private void showBatches_Load(object sender, EventArgs e)
        {
            cmbbid.Items.Clear();
            coursemsEntities obj1 = new coursemsEntities();
            var v1 = from a in obj1.batches.ToList() select a;
            foreach (var item in v1)
            {
                cmbbid.Items.Add(item.batchid);
            }

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            coursemsEntities obj = new coursemsEntities();
            string temp = cmbbid.Text;
            var result = from b in obj.batches
                         where b.batchid == temp
                         select new
                         {
                            b.batchid,
                            b.bsdate,
                            b.bstrength,
                            b.courseid
                         };
            dataGridView1.DataSource = result.ToList();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
         
            coursemsEntities obj = new coursemsEntities();
            var result = from e1 in obj.enrollments.ToList() group e1 by e1.batchid into s select s;
            var v = from b in obj.batches.ToList()
                    join a in result.ToList() on b.batchid equals a.Key
                    select new
                    {
                        batchid = b.batchid,
                        cnt = a.Count(),
                        vacant = b.bstrength - a.Count()
                    };

            dataGridView1.DataSource = v.ToList();


        }
    }
}
