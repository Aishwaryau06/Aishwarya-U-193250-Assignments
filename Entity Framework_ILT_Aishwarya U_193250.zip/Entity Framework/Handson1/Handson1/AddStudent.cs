﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Handson1
{
    public partial class AddStudent : Form
    {
        public AddStudent()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            coursemsEntities obj = new coursemsEntities();
            student s1 = new student();
            s1.sid = txtID.Text;
            s1.sname = txtName.Text;
            s1.sdob = DateTime.Parse(txtDOB.Text);
            s1.scity = txtcity.Text;
            s1.squal = txtqual.Text;
            s1.semail = txtemail.Text;
            s1.sphone = txtphno.Text;
            obj.students.Add(s1);
            obj.SaveChanges();
            MessageBox.Show("inserted successfully");

        }
    }
}
