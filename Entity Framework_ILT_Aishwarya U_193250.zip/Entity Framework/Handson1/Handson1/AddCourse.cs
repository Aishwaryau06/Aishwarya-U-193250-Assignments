﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Handson1
{
    public partial class AddCourse : Form
    {
        public AddCourse()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            coursemsEntities obj = new coursemsEntities();
            course c1 = new course();
            c1.courseid = txtID.Text;
            c1.coursename = txtName.Text;
            c1.coursecategory = txtcat.Text;
            c1.coursefees = decimal.Parse(txtfee.Text);
            c1.courseduration = int.Parse(txtdu.Text);
           
            obj.courses.Add(c1);
            obj.SaveChanges();
            MessageBox.Show("inserted successfully");


        }

        private void AddCourse_Load(object sender, EventArgs e)
        {

        }
    }
}
