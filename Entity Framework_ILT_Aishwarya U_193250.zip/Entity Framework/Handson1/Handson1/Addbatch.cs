﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Handson1
{
    public partial class Addbatch : Form
    {
        public Addbatch()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
             coursemsEntities obj = new coursemsEntities();
            batch b1 = new batch();
            b1.batchid = txtid.Text;
            b1.bsdate = DateTime.Parse(txtDate.Text);
            b1.bstrength = int.Parse(txtstr.Text);
            b1.courseid = cmbcid.Text;
           
           
            obj.batches.Add(b1);
            obj.SaveChanges();
            MessageBox.Show("inserted successfully");
        }

        private void cmbcid_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Addbatch_Load(object sender, EventArgs e)
        {
            cmbcid.Items.Clear();
            coursemsEntities obj = new coursemsEntities();
            var v = from a in obj.courses.ToList() select a;
            foreach(var item in v)
            {
                cmbcid.Items.Add(item.courseid);
            }
        }
    }
}
