﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Handson1
{
    public partial class showStudent : Form
    {
        public showStudent()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            coursemsEntities obj = new coursemsEntities();

            dataGridView1.DataSource = obj.students.ToList() ;
        }

        private void showStudent_Load(object sender, EventArgs e)
        {
            cmbsid.Items.Clear();
            coursemsEntities obj1 = new coursemsEntities();
            var v1 = from a in obj1.students.ToList() select a;
            foreach (var item in v1)
            {
                cmbsid.Items.Add(item.sid);
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            coursemsEntities obj = new coursemsEntities();
            string temp = cmbsid.Text;
            var result = from a in obj.enrollments
                         join b in obj.batches on a.batchid equals b.batchid
                         where a.sid == temp
                         select new
                         {
                             b.batchid,b.bsdate,b.bstrength,b.courseid

                         };
            dataGridView1.DataSource = result.ToList();

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            coursemsEntities obj = new coursemsEntities();
            string temp = cmbsid.Text;
            var result = from a in obj.enrollments
                         join b in obj.batches on a.batchid equals b.batchid
                         join c in obj.courses on b.courseid equals c.courseid
                         where a.sid == temp
                         select new
                         { 
                             c.courseid,
                             c.coursename,
                             c.courseduration,
                             c.coursecategory,
                             c.coursefees

                         };
            dataGridView1.DataSource = result.ToList();

        }
    }
}
