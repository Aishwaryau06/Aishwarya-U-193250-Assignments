﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Handson1
{
    public partial class showCourse : Form
    {

       
        public showCourse()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            coursemsEntities obj = new coursemsEntities();

            dataGridView1.DataSource = obj.courses.ToList();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            coursemsEntities obj = new coursemsEntities();
            string temp = cmbcid.Text;
            var result = from c in obj.courses 
                         where c.courseid == temp
                         select new
                         {
                             c.courseid,
                             c.coursename,
                             c.coursecategory,
                             c.coursefees,
                             c.courseduration,
                            
                             

                         };
            dataGridView1.DataSource = result.ToList();
        }

        private void showCourse_Load(object sender, EventArgs e)
        {
            cmbcid.Items.Clear();
            coursemsEntities obj1 = new coursemsEntities();
            var v1 = from a in obj1.courses.ToList() select a;
            foreach (var item in v1)
            {
                cmbcid.Items.Add(item.courseid);
            }
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            coursemsEntities obj = new coursemsEntities();
            var result = from e1 in obj.enrollments.ToList()
                         join b in obj.batches.ToList() on e1.batchid equals b.batchid
                         group b by b.courseid into s
                         select s;
            var v = from ee in obj.courses.ToList()
                    join b1 in result.ToList() on ee.courseid equals b1.Key
                    select new
                    {
                        courseid = ee.courseid,
                        cnt = b1.Count(),
                        Total_Revenue = b1.Count() * ee.coursefees


                    };
            dataGridView1.DataSource = v.ToList();
        }
    }
}
