﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Handson1
{
    public partial class enroll : Form
    {
        
        public enroll()
        {
            InitializeComponent();
        }

        private void enroll_Load(object sender, EventArgs e)
        {
            cmbbid.Items.Clear();
            coursemsEntities obj = new coursemsEntities();
            var v = from a in obj.batches.ToList() select a;
            foreach (var item in v)
            {
                cmbbid.Items.Add(item.batchid);
            }

            cmbid.Items.Clear();
            coursemsEntities obj1 = new coursemsEntities();
            var v1 = from a in obj1.students.ToList() select a;
            foreach (var item in v1)
            {
                cmbid.Items.Add(item.sid);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            coursemsEntities obj = new coursemsEntities();
            enrollment e1 = new enrollment();
            e1.batchid = cmbbid.Text;
            e1.sid = cmbid.Text;
            e1.edate = DateTime.Parse(txtdate.Text);
            


            obj.enrollments.Add(e1);
            obj.SaveChanges();
            MessageBox.Show("inserted successfully");
            cmbid.Text = "";
            cmbbid.Text = "";
            txtdate.Text = "";
        }
    }
}
