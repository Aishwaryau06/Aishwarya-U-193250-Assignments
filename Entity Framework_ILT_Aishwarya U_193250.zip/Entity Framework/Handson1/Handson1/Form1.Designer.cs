﻿namespace Handson1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.addDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addStudentDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addCouseDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addBatchDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addEnrollmentsDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showStudentDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showCourseDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showBatchDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showEnrollmentsDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addDetailsToolStripMenuItem,
            this.showDetailsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // addDetailsToolStripMenuItem
            // 
            this.addDetailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addStudentDetailsToolStripMenuItem,
            this.addCouseDetailsToolStripMenuItem,
            this.addBatchDetailsToolStripMenuItem,
            this.addEnrollmentsDetailsToolStripMenuItem});
            this.addDetailsToolStripMenuItem.Name = "addDetailsToolStripMenuItem";
            this.addDetailsToolStripMenuItem.Size = new System.Drawing.Size(122, 29);
            this.addDetailsToolStripMenuItem.Text = "Add_Details";
            // 
            // addStudentDetailsToolStripMenuItem
            // 
            this.addStudentDetailsToolStripMenuItem.Name = "addStudentDetailsToolStripMenuItem";
            this.addStudentDetailsToolStripMenuItem.Size = new System.Drawing.Size(308, 34);
            this.addStudentDetailsToolStripMenuItem.Text = "Add_Student_Details ";
            this.addStudentDetailsToolStripMenuItem.Click += new System.EventHandler(this.addStudentDetailsToolStripMenuItem_Click);
            // 
            // addCouseDetailsToolStripMenuItem
            // 
            this.addCouseDetailsToolStripMenuItem.Name = "addCouseDetailsToolStripMenuItem";
            this.addCouseDetailsToolStripMenuItem.Size = new System.Drawing.Size(308, 34);
            this.addCouseDetailsToolStripMenuItem.Text = "Add_Couse_Details";
            this.addCouseDetailsToolStripMenuItem.Click += new System.EventHandler(this.addCouseDetailsToolStripMenuItem_Click);
            // 
            // addBatchDetailsToolStripMenuItem
            // 
            this.addBatchDetailsToolStripMenuItem.Name = "addBatchDetailsToolStripMenuItem";
            this.addBatchDetailsToolStripMenuItem.Size = new System.Drawing.Size(308, 34);
            this.addBatchDetailsToolStripMenuItem.Text = "Add_Batch_Details";
            this.addBatchDetailsToolStripMenuItem.Click += new System.EventHandler(this.addBatchDetailsToolStripMenuItem_Click);
            // 
            // addEnrollmentsDetailsToolStripMenuItem
            // 
            this.addEnrollmentsDetailsToolStripMenuItem.Name = "addEnrollmentsDetailsToolStripMenuItem";
            this.addEnrollmentsDetailsToolStripMenuItem.Size = new System.Drawing.Size(308, 34);
            this.addEnrollmentsDetailsToolStripMenuItem.Text = "Add_Enrollments_Details";
            this.addEnrollmentsDetailsToolStripMenuItem.Click += new System.EventHandler(this.addEnrollmentsDetailsToolStripMenuItem_Click);
            // 
            // showDetailsToolStripMenuItem
            // 
            this.showDetailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showStudentDetailsToolStripMenuItem,
            this.showCourseDetailsToolStripMenuItem,
            this.showBatchDetailsToolStripMenuItem,
            this.showEnrollmentsDetailsToolStripMenuItem});
            this.showDetailsToolStripMenuItem.Name = "showDetailsToolStripMenuItem";
            this.showDetailsToolStripMenuItem.Size = new System.Drawing.Size(132, 29);
            this.showDetailsToolStripMenuItem.Text = "Show_Details";
            this.showDetailsToolStripMenuItem.Click += new System.EventHandler(this.showDetailsToolStripMenuItem_Click);
            // 
            // showStudentDetailsToolStripMenuItem
            // 
            this.showStudentDetailsToolStripMenuItem.Name = "showStudentDetailsToolStripMenuItem";
            this.showStudentDetailsToolStripMenuItem.Size = new System.Drawing.Size(318, 34);
            this.showStudentDetailsToolStripMenuItem.Text = "Show_Student_Details";
            this.showStudentDetailsToolStripMenuItem.Click += new System.EventHandler(this.showStudentDetailsToolStripMenuItem_Click);
            // 
            // showCourseDetailsToolStripMenuItem
            // 
            this.showCourseDetailsToolStripMenuItem.Name = "showCourseDetailsToolStripMenuItem";
            this.showCourseDetailsToolStripMenuItem.Size = new System.Drawing.Size(318, 34);
            this.showCourseDetailsToolStripMenuItem.Text = "Show_Course_Details";
            this.showCourseDetailsToolStripMenuItem.Click += new System.EventHandler(this.showCourseDetailsToolStripMenuItem_Click);
            // 
            // showBatchDetailsToolStripMenuItem
            // 
            this.showBatchDetailsToolStripMenuItem.Name = "showBatchDetailsToolStripMenuItem";
            this.showBatchDetailsToolStripMenuItem.Size = new System.Drawing.Size(318, 34);
            this.showBatchDetailsToolStripMenuItem.Text = "Show_Batch_Details";
            this.showBatchDetailsToolStripMenuItem.Click += new System.EventHandler(this.showBatchDetailsToolStripMenuItem_Click);
            // 
            // showEnrollmentsDetailsToolStripMenuItem
            // 
            this.showEnrollmentsDetailsToolStripMenuItem.Name = "showEnrollmentsDetailsToolStripMenuItem";
            this.showEnrollmentsDetailsToolStripMenuItem.Size = new System.Drawing.Size(318, 34);
            this.showEnrollmentsDetailsToolStripMenuItem.Text = "Show_Enrollments_Details";
            this.showEnrollmentsDetailsToolStripMenuItem.Click += new System.EventHandler(this.showEnrollmentsDetailsToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem addDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addStudentDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addCouseDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addBatchDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addEnrollmentsDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showStudentDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showCourseDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showBatchDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showEnrollmentsDetailsToolStripMenuItem;
    }
}

